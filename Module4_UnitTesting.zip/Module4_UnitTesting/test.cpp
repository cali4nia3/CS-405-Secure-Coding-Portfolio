// Uncomment the next line to use precompiled headers
//#include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    //  initialize random seed
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
  // create a smart point to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { // create a new collection to be used in the test
    collection.reset( new std::vector<int>);
  }

  void TearDown() override
  { //  erase all elements in the collection, if any remain
    collection->clear();
    // free the pointer
    collection.reset(nullptr);
  }

  // helper function to add random values from 0 to 99 count times to the collection
  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  // is the collection created
  ASSERT_TRUE(collection);

  // if empty, the size must be 0
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
  FAIL();
}

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());
  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);

  add_entries(1);

  // is the collection still empty?
  EXPECT_FALSE(collection->empty());
  // if not empty, what must the size be?
  EXPECT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());
  // if empty size must be 0
  ASSERT_EQ(collection->size(), 0);

  add_entries(5);

  // is the collection still empty?
  EXPECT_FALSE(collection->empty());
  // does the collection hold the assigned size?
  EXPECT_EQ(collection->size(), 5);

  // are the values added by add_entries() within the range of 0-99
  for (const auto& value : *collection) {
    EXPECT_GE(value, 0);
    EXPECT_LT(value, 100);
  }
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries

TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToEntriesSize) {

  // 0 entries - checks for empty case and collection size
  ASSERT_TRUE(collection->empty());
  EXPECT_GE(collection->max_size(), collection->size());

  // 1, 5, 10 entries checks collection size and max size for coparison
  // max_size >= size
  for (int count : {1, 5, 10}) {
    SCOPED_TRACE("Entry count: " + std::to_string(count));

    collection->clear();
    add_entries(count);

    ASSERT_EQ(collection->size(), static_cast<size_t>(count));
    EXPECT_GE(collection->max_size(), collection->size());
  }

}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries

TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToEntriesSize) {

  // 0 entries - checks for empty case and collection size
  ASSERT_TRUE(collection->empty());
  EXPECT_GE(collection->capacity(), collection->size());

  // 1, 5, 10 entries checks collection size and max size for coparison
  // capacity >= size
  for (int count : {1, 5, 10}) {
    SCOPED_TRACE("Entry count: " + std::to_string(count));

    collection->clear();
    add_entries(count);

    ASSERT_EQ(collection->size(), static_cast<size_t>(count));
    EXPECT_GE(collection->capacity(), collection->size());
  }

}

// TODO: Create a test to verify resizing increases the collection

// Verify that resizing to a larger size increases the collection, keeps the
// existing values, and fills the new elements with 0
TEST_F(CollectionTest, ResizeIncreasesCollectionSize)
{
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);

  // Saves a copy of original values to compare after resizing collection
  const std::vector<int> original = *collection;

  collection->resize(10);

  // Size increases to 10
  EXPECT_EQ(collection->size(), 10);

  // First values remain unchanged
  for (size_t i = 0; i < original.size(); ++i)
  {
    EXPECT_EQ(collection->at(i), original.at(i));
  }

  // The five new elements should be value-initialized to 0
  for (size_t i = original.size(); i < collection->size(); ++i)
  {
    EXPECT_EQ(collection->at(i), 0);
  }
}

// TODO: Create a test to verify resizing decreases the collection

// Verify that resizing to a smaller size decreases the collection and keeps
// the values at the front
TEST_F(CollectionTest, ResizeDecreasesCollectionSize)
{
  add_entries(10);
  ASSERT_EQ(collection->size(), 10);

  const std::vector<int> original = *collection;

  collection->resize(5);

  // Size should shrink to the requested amount
  EXPECT_EQ(collection->size(), 5);

  // The remaining values should be the first five original values
  for (size_t i = 0; i < collection->size(); ++i)
  {
    EXPECT_EQ(collection->at(i), original.at(i));
  }
}

// TODO: Create a test to verify resizing decreases the collection to zero

// Verify that resizing to zero removes every element from the collection
TEST_F(CollectionTest, ResizeDecreasesCollectionToZero)
{
  add_entries(5);
  ASSERT_FALSE(collection->empty());

  collection->resize(0);

  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify clear erases the collection

// Verify that clear() erases every element from the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
  add_entries(5);
  ASSERT_FALSE(collection->empty());

  collection->clear();

  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify erase(begin,end) erases the collection

// Verify that erase(begin, end) removes every element from the collection
TEST_F(CollectionTest, EraseBeginToEndErasesCollection)
{
  add_entries(10);
  ASSERT_FALSE(collection->empty());

  // Erase the full range; erase() returns an iterator to the element after the last one removed
  auto nextElement = collection->erase(collection->begin(), collection->end());

  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0);

  // With the whole range erased, the returned iterator must be end()
  EXPECT_TRUE(nextElement == collection->end());
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection

// Verify that reserve() increases the capacity but does not change the size
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
  add_entries(5);

  // Record the state before reserving
  const auto originalSize = collection->size();
  const auto originalCapacity = collection->capacity();

  collection->reserve(originalCapacity + 10);

  // Capacity must grow to at least the requested amount
  EXPECT_GT(collection->capacity(), originalCapacity);
  EXPECT_GE(collection->capacity(), originalCapacity + 10);

  // Size must be unchanged; reserve() allocates memory but adds no elements
  EXPECT_EQ(collection->size(), originalSize);
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test

// NEGATIVE TEST: verify at() throws std::out_of_range when the index is out of bounds
TEST_F(CollectionTest, AtThrowsOutOfRangeForInvalidIndex)
{
  // An empty collection has no valid index, so even index 0 is out of bounds
  ASSERT_TRUE(collection->empty());
  EXPECT_THROW(collection->at(0), std::out_of_range);

  add_entries(5);

  // Valid indexes are 0-4; index 5 (== size()) is the first invalid one
  EXPECT_NO_THROW(collection->at(collection->size() - 1));
  EXPECT_THROW(collection->at(collection->size()), std::out_of_range);

  // An index far beyond the end must also throw
  EXPECT_THROW(collection->at(100), std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative

// CUSTOM POSITIVE TEST: verify insert() at begin() places the value first
// and shifts the existing values back by one position
TEST_F(CollectionTest, InsertAtBeginningShiftsExistingValues)
{
  add_entries(3);
  const std::vector<int> original = *collection;

  // 100 is outside the 0-99 range add_entries() produces, so it can't be confused with existing data
  const int insertedValue = 100;
  collection->insert(collection->begin(), insertedValue);

  EXPECT_EQ(collection->size(), original.size() + 1);
  EXPECT_EQ(collection->front(), insertedValue);

  // Each original value should now be one index later
  for (size_t i = 0; i < original.size(); ++i)
  {
    EXPECT_EQ(collection->at(i + 1), original.at(i));
  }
}

// CUSTOM NEGATIVE TEST: verify reserve() throws std::length_error when asked
// for more capacity than the collection can ever hold
TEST_F(CollectionTest, ReserveBeyondMaxSizeThrowsLengthError)
{
  const auto originalCapacity = collection->capacity();

  EXPECT_THROW(collection->reserve(collection->max_size() + 1), std::length_error);

  // The failed request must leave the collection unchanged
  EXPECT_EQ(collection->capacity(), originalCapacity);
  EXPECT_TRUE(collection->empty());
}