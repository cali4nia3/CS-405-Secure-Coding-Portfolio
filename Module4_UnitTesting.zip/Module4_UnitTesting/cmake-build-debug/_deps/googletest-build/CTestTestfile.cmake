# CMake generated Testfile for 
# Source directory: C:/Users/G/CLionProjects/CS-405/Module4_UnitTesting/cmake-build-debug/_deps/googletest-src
# Build directory: C:/Users/G/CLionProjects/CS-405/Module4_UnitTesting/cmake-build-debug/_deps/googletest-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("googlemock")
