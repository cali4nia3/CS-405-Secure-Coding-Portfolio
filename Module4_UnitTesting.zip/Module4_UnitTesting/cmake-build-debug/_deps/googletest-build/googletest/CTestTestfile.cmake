# CMake generated Testfile for 
# Source directory: C:/Users/G/CLionProjects/CS-405/Module4_UnitTesting/cmake-build-debug/_deps/googletest-src/googletest
# Build directory: C:/Users/G/CLionProjects/CS-405/Module4_UnitTesting/cmake-build-debug/_deps/googletest-build/googletest
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
