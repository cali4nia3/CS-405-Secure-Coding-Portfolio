// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <algorithm>
#include <string>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  // Added the addition of a temporary input string variable
  std::string temp_input;
  // Condition check boolean for while loop
  bool valid_input = false;

  // While valid_input is false, prompts user to enter value under overflow limit
  while (!valid_input) {
    std::cout << "Enter a value: ";
    std::getline(std::cin, temp_input);

    // Checks the length of temp_input to the size of char array user_input
    // If temp_input length is equal to or greater, prints warning
    if (temp_input.length() >= sizeof(user_input)) {
      std::cout << "User input too long! Buffer overflow prevented.\n"
                << "Please enter 19 characters or less." << std::endl;
    } else {
      // Copy string into char array using .begin() and .end()
      std::copy(temp_input.begin(), temp_input.end(), user_input);
      // Adds null terminator to signify end of string
      user_input[temp_input.length()] = '\0';
      // Updates while loop condition to true
      valid_input = true;
    }
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
