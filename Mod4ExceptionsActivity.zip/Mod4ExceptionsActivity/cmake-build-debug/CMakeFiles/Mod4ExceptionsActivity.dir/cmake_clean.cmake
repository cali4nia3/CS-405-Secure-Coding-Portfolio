file(REMOVE_RECURSE
  "CMakeFiles/Mod4ExceptionsActivity.dir/Exceptions.cpp.obj"
  "CMakeFiles/Mod4ExceptionsActivity.dir/Exceptions.cpp.obj.d"
  "Mod4ExceptionsActivity.exe"
  "Mod4ExceptionsActivity.exe.manifest"
  "Mod4ExceptionsActivity.pdb"
  "libMod4ExceptionsActivity.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/Mod4ExceptionsActivity.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
