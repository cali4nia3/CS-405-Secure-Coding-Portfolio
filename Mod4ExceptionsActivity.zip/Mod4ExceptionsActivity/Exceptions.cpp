// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>
#include <stdexcept>

// Custom exception from the std::exception class allowing for
// application specific errors to be handled separately
class CustomException : public std::exception {
    public:
        [[nodiscard]] const char * what() const noexcept override {
            return "Custom Exception";
        }
};


bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throws a standard exception to simulate an error in custom application logic
    throw std::invalid_argument("Invalid Argument in Even More Custom Application Logic");

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    // If statement within try block to ensure any errors are caught
    // and program continues operating properly
    try {
        if(do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    // Catches standard exception in Custom Application Logic and prints what() text
    catch (const std::exception& e) {
        std::cout << "Standard exception in Custom Application Logic caught: "
                    << e.what() << std::endl;
    }


    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    // Throws custom exception so it can be handled within main function
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined

    // Prevention for division by 0 by checking if denominator value is 0.0f
    // if so, throws invalid_argument exception
    if (den == 0.0f) {
        throw std::invalid_argument("Division by zero");
    }

    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //   by divide.

    float numerator = 10.0f;
    float denominator = 0;

    // Try/Catch block to catch division by 0 and throw appropriate exception
    // with what() description
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = "
                    << result << std::endl;
    }
    catch (const std::invalid_argument& e) {
        std::cout << "Invalid Argument in Division by zero: "
                    << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception
    //  that wraps the whole main function, and displays a message to the console.

    // Two functions surrounded by try/catch block with cascading catch statements
    // in charge of handling CustomException(), standard exceptions, and any other
    // uncaught exceptions
    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e) {
        std::cout << "Custom exception caught: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cout << "Standard exception caught: " << e.what() << std::endl;
    }
    catch (...) {
        std::cout << "Unknown exception caught" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu